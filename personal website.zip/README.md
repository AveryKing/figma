
  # Personal Website Builder

  This is a code bundle for Personal Website Builder. The original project is available at https://www.figma.com/design/u5pgD52eGV8Lko1MEecZQI/Personal-Website-Builder.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  